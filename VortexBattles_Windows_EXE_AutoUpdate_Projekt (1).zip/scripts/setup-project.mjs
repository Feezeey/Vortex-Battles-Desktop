import fs from 'node:fs';
import path from 'node:path';
const repo = process.argv[2];
const pubfile = process.argv[3];
if (!repo || !pubfile || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo)) {
  console.error('Aufruf: node scripts/setup-project.mjs DEINNAME/DEINREPO "PFAD_ZUR_KEY.PUB"');
  process.exit(1);
}
let pubkey;
try { pubkey = fs.readFileSync(pubfile, 'utf8').trim(); }
catch { console.error('Öffentlicher Schlüssel nicht gefunden:', pubfile); process.exit(1); }
if (!pubkey || !pubkey.includes('untrusted comment:') || pubkey.length < 90) {
  console.error('Das ist keine gültige Tauri .key.pub-Datei (Public Key).');
  process.exit(1);
}
const fn=path.join('src-tauri','tauri.conf.json');
const cfg=JSON.parse(fs.readFileSync(fn,'utf8'));
cfg.plugins.updater.pubkey=pubkey;
cfg.plugins.updater.endpoints=[`https://github.com/${repo}/releases/latest/download/latest.json`];
fs.writeFileSync(fn,JSON.stringify(cfg,null,2)+'\n');
console.log('✓ Update-Endpunkt:',cfg.plugins.updater.endpoints[0]);
console.log('✓ Öffentlicher Signatur-Schlüssel gesetzt. Privaten Schlüssel NICHT in GitHub-Dateien hochladen.');
